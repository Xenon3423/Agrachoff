<!-- <?php
        $email = $_POST['email'];
        $email = htmlspecialchars($email);
        $email = urldecode($email);
        $email = trim($email);
        mail($email, "Привет", "Привет \r\n")
        ?> -->



<!-- if (mail("example@mail.ru", "Привет", "ФИО:".$fio.". E-mail: ".$email ,"From: example2@mail.ru \r\n"))
 {     echo "сообщение успешно отправлено";
} else {
    echo "при отправке сообщения возникли ошибки"; -->


    <!-- mail($email, "Привет", "ФИО:" . $fio . ". E-mail: " . $email, "From: example2@mail.ru \r\n") -->
